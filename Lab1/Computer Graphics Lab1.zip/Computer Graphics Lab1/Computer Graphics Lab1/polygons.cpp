#include "pch.h"
//================================
// polygons.cpp
// all polygons and lines
//================================
polygons::polygons()
{
	this->polygons_num = 0;
}

void polygons::set_polygons(int polygons_num)
{
	this->polygons_num = polygons_num;
	polygon* allpolygons = new polygon[polygons_num];
}

polygons::~polygons()
{
}

int polygons::get_polygons_num()
{
	return polygons_num;
}

void polygons::show_all_polygons()
{
	for (int i = 0; i < polygons_num; i++)
	{
		cout << allpolygons[i].vertex_num<<endl;
		for(int j = 0;j< allpolygons[i].vertex_num;j++)
		cout << allpolygons[i].lines[j].start<<"\t"<< allpolygons[i].lines[j].end<<endl;
	}
}

void polygons::show_all_lines() {
	for (int i = 0; i < polygons_num; i++)
	{
		for (int j = 0; j < allp.allpolygons[i].vertex_num; j++) {
			allv.allvertices[allp.allpolygons[i].lines[j].start].showVector();
			allv.allvertices[allp.allpolygons[i].lines[j].end].showVector();
		}

	}
}
