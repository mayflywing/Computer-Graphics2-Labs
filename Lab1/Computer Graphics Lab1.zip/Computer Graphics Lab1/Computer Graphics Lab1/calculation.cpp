#include "pch.h"
//================================
// calculation.cpp
// some function for MyVector and matrix
//================================


//calculate the MyVector product of a and b
MyVector  Xproduct(MyVector a, MyVector b) {
	return MyVector(a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x);
}

//calculate the distance between vertex a and vertex b
float Distance(MyVector a, MyVector b) {
	return sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) + (a.z - b.z)*(a.z - b.z));
}

float *MultiMatrix(Matrix a, Matrix b) {
	float *temp;
	temp = new float[16];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			temp[4 * i + j] = 0.0;
			for (int k = 0; k < 4; k++) {
				temp[i * 4 + j] += a.matrix[4 * k + j] * b.matrix[4 * i + k];
			}
		}
	}
	return temp;
}

float Random() {		//return a float between [0, 1]
	float a, b;
	a = (float)abs(rand()), b = (float)abs(rand());
	if (a > b)
		return b / a;
	else return a / b;
}

//�ַ����ָ��
vector<string> split(const string &s, char splitchar)
{
	auto start = 0;
	auto length = s.length();
	string tt;
	vector<string> tmp;
	if (tmp.size() > 0)
		tmp.clear();
	for (auto i = 0; i < length; i++)
	{
		if (s[i] == splitchar && i == 0)
			start++;
		else if (s[i] == splitchar)
		{
			tt = s.substr(start, i - start);
			if (!tt.empty())
			{
				tmp.push_back(tt);
			}
			start = i + 1;
		}
		else if (i == length - 1)
		{
			tt = s.substr(start, i - start + 1);
			if (!tt.empty())
			{
				tmp.push_back(tt);
			}
			start = i + 1;
		}
	}
	return tmp;

}
//�ַ����滻
string&   replace_all(string&   str, const   string&   old_value, const   string&   new_value)
{
	while (true) {
		string::size_type   pos(0);
		if ((pos = str.find(old_value)) != string::npos)
			str.replace(pos, old_value.length(), new_value);
		else   break;
	}
	return   str;
}