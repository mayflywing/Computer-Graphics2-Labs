#ifndef __CALCULATION__
#define __CALCULATION__
//================================
// calculation.h
// some function for vector and matrix
//================================

MyVector  Xproduct(MyVector a, MyVector b);
float Distance(MyVector a, MyVector b);
; float *MultiMatrix(Matrix a, Matrix b);
float Random();

vector<string> split(const string & s, char splitchar);

string & replace_all(string & str, const string & old_value, const string & new_value);

#endif  //__CALCULATION__