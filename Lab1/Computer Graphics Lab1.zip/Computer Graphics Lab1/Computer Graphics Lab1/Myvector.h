#ifndef __VECTOR__
#define __VECTOR__
//================================
// MyVector.h
// Used to store and calculate the coordinates of the vertices
//================================
class MyVector {
public:
	float x, y, z;

public:
	MyVector();
	MyVector(float x, float y, float z);

	MyVector &		set(float x, float y, float z);

	MyVector &		zero(void);

	MyVector			operator- (void) const;
	MyVector			operator+ (void) const;

	MyVector			operator+ (const MyVector &v) const;
	MyVector			operator- (const MyVector &v) const;
	MyVector			operator* (float scalar) const;
	MyVector			operator/ (float scalar) const;

	//overload operator *, calcluate vector*vector
	double			operator* (const MyVector &v) const;

	MyVector &		operator= (const MyVector &v);
	MyVector &		operator+=(const MyVector &v);
	MyVector &		operator-=(const MyVector &v);
	MyVector &		operator*=(float scalar);
	MyVector &		operator/=(float scalar);




	float &			operator[](int index);
	const float &	operator[](int index) const;

	float			dot(const MyVector &v) const;

	float			magnitude(void) const;
	MyVector &		normalize(void);

	float *			ptr(void);
	const float *	ptr(void) const;

	// calcluate vector*Matrix
	MyVector 		operator* (const Matrix &m)const;

	void showVector();

public:
	friend MyVector	operator*(float scalar, const MyVector &v);
};




#endif // __VECTOR__
