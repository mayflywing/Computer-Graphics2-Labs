#ifndef __PREFERENCE__
#define __PREFERENCE__

//================================
// global variables
//================================

//��ͷ
extern float h,dnear,dfar;
extern float winWidth, winHeight;
extern float Theta, Dnear, Dfar;

extern MyVector C;
extern MyVector pref;
extern MyVector Up;

extern Camera camera;

//�ļ�
extern string file_name;

//�������
extern vertices allv;
extern polygons allp;


extern int vertices_num;
extern int polygons_num;


#endif //__PREFERENCE__