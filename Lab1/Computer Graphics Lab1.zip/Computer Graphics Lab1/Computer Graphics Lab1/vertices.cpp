#include"pch.h"
//================================
// vertices.cpp
// all vertices
//================================

vertices::vertices()
{
	this->vertices_num = 0;
}

vertices::~vertices()
{
}
void vertices::set_vertices(int vertices_num)
{
	this->vertices_num = vertices_num;
	MyVector* allvertices = new MyVector[vertices_num];
}



int vertices::get_vertices_num()
{
	return vertices_num;
}

void vertices::show_all_vertices()
{
	for (int i = 0; i < this->vertices_num;i++)
	{
		allvertices[i].showVector();
	}
}
