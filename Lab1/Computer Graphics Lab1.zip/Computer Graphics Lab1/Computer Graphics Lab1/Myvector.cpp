#include "pch.h"
//================================
// MyVector.cpp
// Used to store and calculate the coordinates of the vertices
//================================

MyVector::MyVector() {
	x = y = z = 0;
}

MyVector::MyVector(float x, float y, float z) {
	this->x = x;
	this->y = y;
	this->z = z;
}

MyVector &MyVector::set(float x, float y, float z) {
	this->x = x;
	this->y = y;
	this->z = z;

	return *this;
}

MyVector &MyVector::zero(void) {
	x = y = z = 0;

	return *this;
}

MyVector MyVector::operator-(void) const {
	return MyVector(-x, -y, -z);
}

MyVector MyVector::operator+(void) const {
	return MyVector(x, y, z);
}

MyVector MyVector::operator+(const MyVector &v) const {
	return MyVector(x + v.x, y + v.y, z + v.z);
}

MyVector MyVector::operator-(const MyVector &v) const {
	return MyVector(x - v.x, y - v.y, z - v.z);
}

MyVector MyVector::operator*(float scalar) const {
	return MyVector(x * scalar, y * scalar, z * scalar);
}

double MyVector::operator* (const MyVector &v) const {
	return x * v.x + y * v.y + z * v.z;
}

MyVector MyVector::operator/(float scalar) const {
	float inv = 1.0f / scalar;
	return MyVector(x * inv, y * inv, z * inv);
}

MyVector &MyVector::operator=(const MyVector &v) {
	x = v.x;
	y = v.y;
	z = v.z;
	return *this;
}

MyVector &MyVector::operator+=(const MyVector &v) {
	x += v.x;
	y += v.y;
	z += v.z;
	return *this;
}

MyVector &MyVector::operator-=(const MyVector &v) {
	x -= v.x;
	y -= v.y;
	z -= v.z;
	return *this;
}

MyVector &MyVector::operator*=(float scalar) {
	x *= scalar;
	y *= scalar;
	z *= scalar;
	return *this;
}

MyVector &MyVector::operator/=(float scalar) {
	float inv = 1.0f / scalar;
	x *= inv;
	y *= inv;
	z *= inv;
	return *this;
}

float &MyVector::operator[](int index) {
	assert(index >= 0 && index < 3);
	return (&x)[index];
}

const float &MyVector::operator[](int index) const {
	assert(index >= 0 && index < 3);
	return (&x)[index];
}

float MyVector::dot(const MyVector &v) const {
	return x * v.x + y * v.y + z * v.z;
}

float MyVector::magnitude(void) const {
	return sqrtf(x * x + y * y + z * z);
}

MyVector &MyVector::normalize(void) {
	float magnitude = this->magnitude();


	if (magnitude < 1e-6f) {
		x = y = z = 0;
	}
	else {
		float inv = 1.0f / magnitude;

		x *= inv;
		y *= inv;
		z *= inv;
	}

	return *this;
}

float *MyVector::ptr(void) {
	return &x;
}

const float *MyVector::ptr(void) const {
	return &x;
}

MyVector operator*(float scalar, const MyVector &v) {
	return MyVector(v.x * scalar, v.y * scalar, v.z * scalar);
}

//overload operator *, calcluate MyVector*Matrix
MyVector MyVector::operator*(const Matrix &m) const {
	float a[4] = { 0.0, 0.0, 0.0, 1.0 };
	float b[4] = { 0.0, 0.0, 0.0, 0.0 };
	a[0] = x;
	a[1] = y;
	a[2] = z;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			b[i] += a[j] * m.matrix[4 * j + i];
		}
	}
	return MyVector(b[0] / b[3], b[1] / b[3], b[2] / b[3]);

}

void MyVector::showVector()
{
	cout << "x:" << x << "\t";
	cout << "y:" << y << "\t";
	cout << "z:" << z << "\n";
}
