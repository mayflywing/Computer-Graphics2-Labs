#ifndef __VERTICES__
#define __VERTICES__
//================================
// vertices.h
// all vertices
//================================

class vertices
{
public:
	int vertices_num;
	MyVector allvertices[99999];

public:
	vertices();
	void set_vertices(int vertices_num);
	~vertices();
	int get_vertices_num();
	void show_all_vertices();

};

#endif //__VERTICES__