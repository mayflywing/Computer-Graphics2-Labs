#ifndef __POLYGONS__
#define __POLYGONS__
//================================
// polygons.h
// all polygons and lines
//================================
typedef struct  {
	int start, end;
}line;
typedef struct  {
	int vertex_num;
	line lines[10];
	bool face; //visible or not
}polygon;

class polygons {
public:
	
	int polygons_num;
	polygon allpolygons[99999];
public:
	polygons();
	void set_polygons(int polygons_num);
	~polygons();
	int get_polygons_num();
	void show_all_polygons();
	void show_all_lines();
};


#endif //__POLYGONS__
