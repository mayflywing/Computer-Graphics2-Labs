#ifndef __VERTICES__
#define __VERTICES__
//================================
// vertices.h
// all vertices
//================================

class vertices
{
public:
	int index;
	int vertices_num;
	MyVector *allvertices;
	int ymin, ymax;//���е��ymin��ymax����scanline��ɨ�跶Χ

public:
	vertices();
	void set_vertices(int index,int vertices_num);
	~vertices();
	int get_vertices_num();
	void show_all_vertices();
	void find_scan_line_scope();

};

#endif //__VERTICES__