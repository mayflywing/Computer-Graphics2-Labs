#ifndef __POLYGONS__
#define __POLYGONS__
//================================
// polygons.h
// all polygons and lines
//================================
typedef struct  {
	int start, end;
}line;

typedef struct  {
	int vertex_num;
	line lines[10];
	int vertices_in_one_polygon[10];
	bool face; //visible or not
	float color_r, color_g, color_b;//RGB
}polygon;



class polygons {
public:
	int index;
	int polygons_num;
	polygon *allpolygons;
	vector<edge> *edgetables;

public:
	polygons();
	void set_polygons(int index,int polygons_num);
	~polygons();
	int get_polygons_num();
	void show_all_polygons();
	void show_all_lines();
	void randomcolor();
	void creat_edgetable();
	void ScanConvertion();
};


#endif //__POLYGONS__
