#include "pch.h"

DrawLine::DrawLine()
{
}
/*
DrawLine::DrawLine(vector<int> start, vector<int> end, MyVector color)
{
	this->start = start;
	this->end = end;
	this->color = color;
}
*/

DrawLine::DrawLine(MyVector start, MyVector end, MyVector color)
{
	this->start = start;
	this->end = end;
	this->color = color;
}




DrawLine::~DrawLine()
{
}
