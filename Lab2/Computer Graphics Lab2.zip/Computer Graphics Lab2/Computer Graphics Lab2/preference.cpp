#include "pch.h"
//================================
// global variables
//================================

//��Ļ����
float h=10.0f, dnear=10.0f, dfar=40.0f;


float winWidth = 600.0, winHeight = 600.0;	//window size
float Theta = 20.0f, Dnear = 0.01f, Dfar = 100.0f;	//perspective parameter theta, aspect, dnear, dfar


//��ͷ����
MyVector C = {0,1,1};
MyVector pref = { 0,0,0 };
MyVector Up = {0,-1,0};
Camera camera;

//�ļ�·��
//string file_name = "D files/knight.d";

//������������
//int vertices_num;
//int polygons_num;

//���ж���
int models_num = 0;
vertices *allv = new vertices[10];
polygons *allp = new polygons[10];

vector<DrawLine> DrawLines;

//Zbuffer ��ʼ��Ϊ����ɫ
vector<float> temp1(2001, 9999.0f);
vector<MyVector> temp2(2001, MyVector{ 0,0,0 });
vector<vector<float>> Z_depth(2001,temp1);
vector<vector<MyVector>> Z_frame(2001,temp2);

//vector<vector<float>> Z_depth;
//vector<vector<MyVector>> Z_frame;