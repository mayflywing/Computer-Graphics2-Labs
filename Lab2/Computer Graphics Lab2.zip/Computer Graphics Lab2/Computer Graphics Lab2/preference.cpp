#include "pch.h"
//================================
// global variables
//================================

//��Ļ����
float h=2.0f, dnear=25.0f, dfar=200.0f;


float winWidth = 600.0, winHeight = 600.0;	//window size


//��ͷ����
MyVector C = { 10,50,-50 };
MyVector pref = { 0,0,0 };
MyVector Up = { 0,1,0 };

Camera camera;


//������������
//int vertices_num;
//int polygons_num;

//���ж���
int models_num = 0;
vertices *allv = new vertices[10];
polygons *allp = new polygons[10];


//Zbuffer ��ʼ��Ϊ����ɫ
vector<float> temp1(2001, 9999.0f);
vector<MyVector> temp2(2001, MyVector{ 0,0,0 });
vector<vector<float>> Z_depth(2001,temp1);
vector<vector<MyVector>> Z_frame(2001,temp2);

//vector<vector<float>> Z_depth;
//vector<vector<MyVector>> Z_frame;