#ifndef __PREFERENCE__
#define __PREFERENCE__

//================================
// global variables
//================================

//��ͷ
extern float h,dnear,dfar;
extern float winWidth, winHeight;
extern float Theta, Dnear, Dfar;

extern MyVector C;
extern MyVector pref;
extern MyVector Up;

extern Camera camera;

//�ļ�
//extern string file_name;

//�������
//extern Model models[2];
extern int models_num;
extern vertices *allv;
extern polygons *allp;


//extern int vertices_num;
//extern int polygons_num;



//Zbuffer
extern vector<vector<float>> Z_depth; //�������
extern vector<vector<MyVector>> Z_frame;//��ɫ����

#endif //__PREFERENCE__