#include "pch.h"
//================================
// camera.cpp
// store the position of camera, the viewing direction and the up vector, 
// then calculate the camera coordinates.
//================================

Camera::Camera() {
	View.init();
}
Camera::~Camera(){

}

void Camera::Coordinate(MyVector Camera_Position, MyVector Viewing_Direction, MyVector Up) {
	//Calculate the Camera coordinate
	this->Camera_Position = Camera_Position;//���λ��
	this->Viewing_Direction = Viewing_Direction;//���߷���
	this->Up = Up;//�Ϸ�
	this->N = Viewing_Direction - Camera_Position;
	this->N.normalize();
	this->U = Xproduct(N, Up);
	this->U.normalize();
	this->V = Xproduct(N, U);
	
}

void Camera::Camera_Space() {
	Matrix R, T;
	R.init();//Rotate so that the axes coincide
		R.matrix[0] = U.x, R.matrix[4] = U.y, R.matrix[8] = U.z,  R.matrix[12] = 0,
		R.matrix[1] = V.x, R.matrix[5] = V.y, R.matrix[9] = V.z,  R.matrix[13] = 0,
		R.matrix[2] = N.x, R.matrix[6] = N.y, R.matrix[10] = N.z, R.matrix[14] = 0,
		R.matrix[3] = 0,   R.matrix[7] = 0,   R.matrix[11] = 0,   R.matrix[15] = 1;
		
	T.init();//Translate so that viewing coordinate origin is coincident with world coordinate
		T.matrix[0] = 1, T.matrix[4] = 0, T.matrix[8] = 0, T.matrix[12] = -Camera_Position.x,
		T.matrix[1] = 0, T.matrix[5] = 1, T.matrix[9] = 0, T.matrix[13] = -Camera_Position.y,
		T.matrix[2] = 0, T.matrix[6] = 0, T.matrix[10] = 1, T.matrix[14] = -Camera_Position.z,
		T.matrix[3] = 0, T.matrix[7] = 0, T.matrix[11] = 0, T.matrix[15] = 1;
		
		
	View.init();//��ʼ��M-view����
	R.MultiMatrix(T);
	View.SetMatrix(R);//View =R��T
}