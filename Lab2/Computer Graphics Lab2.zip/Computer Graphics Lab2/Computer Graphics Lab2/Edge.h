#ifndef __EDGE__
#define __EDGE__
//================================
// Edge.h
// edges in scanline
//================================
class edge {
public:
	int Ymin, Ymax;
	float Xmin, x_over_y,Zmin,z_over_y;
public:
	edge();
	~edge();
	edge & operator= (const edge &e);
};

#endif //__EDGE__