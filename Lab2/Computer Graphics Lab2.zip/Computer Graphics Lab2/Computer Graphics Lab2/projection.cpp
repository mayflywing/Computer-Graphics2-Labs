#include "pch.h"
//================================
// projection.cpp
// the perspective matrix
//================================



Matrix perspective(float theta, float aspect, float dnear, float dfar){
	Matrix temp;
	temp.init();
	temp.matrix[0] = 2.0 / tan(theta / 2.0) / aspect;
	temp.matrix[5] = 2.0 / tan(theta / 2.0);
	temp.matrix[10] = (dnear + dfar) / (dnear - dfar);
	temp.matrix[11] = -1.0;
	temp.matrix[14] = 2.0*dnear*dfar / (dfar - dnear);
	return temp;

}


Matrix perspective() {

	Matrix perspective;
	perspective.init();
	perspective.matrix[0] = dnear/h, perspective.matrix[4] = 0, perspective.matrix[8] = 0, perspective.matrix[12] = 0,
	perspective.matrix[1] = 0, perspective.matrix[5] = dnear/h, perspective.matrix[9] = 0, perspective.matrix[13] = 0,
	perspective.matrix[2] = 0, perspective.matrix[6] = 0, perspective.matrix[10] = dfar/(dfar-dnear), perspective.matrix[14] = -dnear*dfar/(dfar-dnear),
	perspective.matrix[3] = 0, perspective.matrix[7] = 0, perspective.matrix[11] = 1, perspective.matrix[15] = 0;

	return perspective;
}


MyVector model(Camera camera, MyVector v) {
	Matrix Temp;
	//Temp.SetMatrix(perspective(Theta, winWidth/winHeight,Dnear,Dfar));
	//Temp.MultiMatrix(frustum());
	Temp.SetMatrix(perspective());
	Temp.MultiMatrix(camera.View);
	
	return v * Temp;
}

void LoadData(string file_name) {
	ifstream text;
	text.open(file_name, ios::in);

	vector<string> strVec;
	while (!text.eof())  //��0 - ��lines��Ӧstrvect[0] - strvect[lines]
	{
		string inbuf;
		getline(text, inbuf, '\n');
		inbuf = replace_all(inbuf, "\t", " ");
		strVec.push_back(inbuf);
	}

	int vertices_num = stoi(split(strVec[0], ' ')[1]);
	int polygons_num = stoi(split(strVec[0], ' ')[2]);

	vertices v;
	v.set_vertices(models_num, vertices_num);
	polygons p;
	p.set_polygons(models_num, polygons_num);

	
	for (int i = 1; i <= vertices_num; i++)
	{
		float x, y, z;
		stringstream s1(split(strVec[i], ' ')[0]);
		stringstream s2(split(strVec[i], ' ')[1]);
		stringstream s3(split(strVec[i], ' ')[2]);
		s1 >> x;
		s2 >> y;
		s3 >> z;

		//MyVector temp = { x,y,z };
		v.allvertices[i] = { x,y,z };//�����Ŵ�1��ʼ
	}
	
	for (int i = vertices_num + 1; i <= vertices_num + polygons_num; i++)
	{
		polygon temp;
		temp.vertex_num = stoi(split(strVec[i], ' ')[0]);
		for (int k = 0; k < temp.vertex_num; k++)
		{
			temp.vertices_in_one_polygon[k] = stoi(split(strVec[i], ' ')[k + 1]);
		}

		for (int j = 0; j < temp.vertex_num - 1; j++)
		{
			temp.lines[j].start = stoi(split(strVec[i], ' ')[j + 1]);
			temp.lines[j].end = stoi(split(strVec[i], ' ')[j + 2]);
		}
		temp.lines[temp.vertex_num - 1].end = stoi(split(strVec[i], ' ')[1]);
		temp.lines[temp.vertex_num - 1].start = stoi(split(strVec[i], ' ')[temp.vertex_num]);


		p.allpolygons[i - vertices_num - 1] = temp;//��ı�Ŵ�0��ʼ
	}
	
	allv[models_num] = v;
	allp[models_num] = p;
	models_num++;

	
}

void transform() {
	camera.Coordinate(C, pref, Up);
	camera.Camera_Space();

	for (int i = 0; i < models_num; i++) {
		vertices v = allv[i];
		for (int j = 1; j <= v.get_vertices_num(); j++)
		{
			v.allvertices[j] = model(camera, v.allvertices[j]);
		}
	}
}
void back_face_culling() {
	//ȥ��������camera����
	for (int i = 0; i < models_num; i++)
	{
		vertices v = allv[i];
		polygons p = allp[i];
		for (int j = 0; j < p.polygons_num; j++) {
			MyVector v1, v2, v3, line1, line2, normal;
			v1 = v.allvertices[p.allpolygons[j].lines[0].start];
			v2 = v.allvertices[p.allpolygons[j].lines[0].end];
			v3 = v.allvertices[p.allpolygons[j].lines[1].end];
			line1 = v2 - v1;
			line2 = v3 - v2;
			normal = Xproduct(line1, line2);
			if (normal.z > 0) {
				p.allpolygons[j].face = false;
			}

		}
	}
}

void scanline() {
	for (int i = 0; i < models_num; i++)
	{
		//���ģ�ͣ��ֱ�ɨ��ÿ����
		allv[i].find_scan_line_scope(); //in vertices.cpp
		allp[i].randomcolor();//��ȡ���ɫ  //in polygons.cpp
		allp[i].creat_edgetable(); //����edgetable //in polygons.cpp
		allp[i].ScanConvertion(); //���ÿ���� //in polygons.cpp
	}
}
void zbuffer() {
	//�������ת����pixel����zbuffer
	for (int i = 0; i < DrawLines.size(); i++) {
		int y = (int)DrawLines[i].start.y;
		if(y>2000||y<0){
			continue;
		}

		MyVector left, right;
		MyVector color = DrawLines[i].color;
		
		left = DrawLines[i].start;
		right = DrawLines[i].end;
		

		int x1 = (int)left.x;
		int x2 = (int)right.x;
		float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
		float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z
		if (x1 != x2) {
			for (int x = x1; x <= x2; x++)
			{
				if (x > 2000 || x < 0) {
					continue;
				}
				float zp = z2 - (z2 - z1)*(x2 - x) / (x2 - x1);
				if (zp < Z_depth[x][y]) {
					Z_depth[x][y] = zp;
					Z_frame[x][y] = color;
				}
			}
		}
		else {
			float zp;
			if (z1 <= z2) { zp = z1; }
			else { zp = z2; }
			if (zp < Z_depth[x1][y]) {
				Z_depth[x1][y] = zp;
				Z_frame[x1][y] = color;
			}
		}
	}
	
}
