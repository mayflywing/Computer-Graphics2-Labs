#include "pch.h"
//================================
// polygons.cpp
// all polygons and lines
//================================
polygons::polygons()
{
	this->polygons_num = 0;
}

void polygons::set_polygons(int index,int polygons_num)
{
	this->index = index;
	this->polygons_num = polygons_num;
	this->allpolygons = new polygon[polygons_num];
	this->edgetables = new vector<edge>[polygons_num];
}

polygons::~polygons()
{
}

int polygons::get_polygons_num()
{
	return polygons_num;
}

void polygons::show_all_polygons()
{
	for (int i = 0; i < polygons_num; i++)
	{
		cout << allpolygons[i].vertex_num<<endl;
		for(int j = 0;j< allpolygons[i].vertex_num;j++)
		cout << allpolygons[i].lines[j].start<<"\t"<< allpolygons[i].lines[j].end<<endl;
	}
}

void polygons::show_all_lines() {
	for (int i = 0; i < polygons_num; i++)
	{
		for (int j = 0; j < this->allpolygons[i].vertex_num; j++) {
			allv[this->index].allvertices[allpolygons[i].lines[j].start].showVector();
			allv[this->index].allvertices[allpolygons[i].lines[j].end].showVector();
		}

	}
}

void polygons::randomcolor()
{
	//assign each polygon a random color
	for (int i = 0; i < polygons_num; i++)
	{
		
		allpolygons[i].color_r = Random();
		allpolygons[i].color_g = Random();
		allpolygons[i].color_b = Random();
		
	}
}

void polygons::creat_edgetable()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���

			for (int j = 0; j < vernum; j++) {
				vertices[j] = v.allvertices[one_polygon.vertices_in_one_polygon[j]];
			}

			vector<edge> temptable = edgetables[i];

			for (int j = 0; j < vernum; j++)
			{
				MyVector v1, v2;
				float ymin, ymax, xmin, dx, zmin, dz;
				edge tempedge;


				v1 = vertices[j];
				v2 = vertices[(j + 1 + vernum) % vernum];



				//v1,v2�ǵ�ǰ�����ı�
				dx = (v1.x - v2.x) / (v1.y - v2.y);//x over y
				dz = (v1.z - v2.z)/ (v1.y - v2.y);//z over y


				if ((int)v1.y == (int)v2.y) {//ˮƽ�ߺ���
					continue;
				}

				if (v1.y < v2.y) {
					ymin = (int)v1.y;
					ymax = (int)v2.y - 1;
					xmin = v1.x;
					zmin = v1.z;

				}
				else if (v1.y > v2.y) {
					ymin = (int)v2.y;
					ymax = (int)v1.y- 1;
					xmin = v2.x;
					zmin = v2.z;

				}


				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;
				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;
				temptable.push_back(tempedge);//����һ��ɨ����

			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����
			edgetables[i] = temptable;
		}
	}
}


void polygons::ScanConvertion() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];

		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			MyVector color = { one_polygon.color_r,one_polygon.color_g,one_polygon.color_b };//��ǰ�����ɫ
			int vernum = one_polygon.vertex_num;


			for (int j = v.ymin - 1; j <= v.ymax + 1; j++) {//��ʼɨ��
				for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if (edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);
					}
					else if (edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {

					MyVector start, end;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k + 1].Zmin };

					int y = j;
					if (y > 2000 || y < 0) {

					}
					else {
						MyVector left, right;

						left = start;
						right = end;


						int x1 = (int)left.x;
						int x2 = (int)right.x;
						float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
						float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z
						float zoverx = (z2 - z1) / (right.x - left.x);

						float zp = z1;

						for (int x = x1; x <= x2; x++)
						{
							//zp = z2 - (z2 - z1) * (x2 - x) / (x2 - x1);
							if (x > 2000 || x < 0) {

							}
							else if (zp <= Z_depth[x][y]) {
								Z_depth[x][y] = zp;
								Z_frame[x][y] = color;
							}
							zp += zoverx;
						}
					}


				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if (AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin += AET[k].x_over_y;
					AET[k].Zmin += AET[k].z_over_y;

					//For each entry remaining in AET, replace x by x + increment
				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}