#include "pch.h"
//================================
// polygons.cpp
// all polygons and lines
//================================
polygons::polygons()
{
	this->polygons_num = 0;
}

void polygons::set_polygons(int index,int polygons_num)
{
	this->index = index;
	this->polygons_num = polygons_num;
	this->allpolygons = new polygon[polygons_num];
	this->edgetables = new vector<edge>[polygons_num];
}

polygons::~polygons()
{
}

int polygons::get_polygons_num()
{
	return polygons_num;
}

void polygons::show_all_polygons()
{
	for (int i = 0; i < polygons_num; i++)
	{
		cout << allpolygons[i].vertex_num<<endl;
		for(int j = 0;j< allpolygons[i].vertex_num;j++)
		cout << allpolygons[i].lines[j].start<<"\t"<< allpolygons[i].lines[j].end<<endl;
	}
}

void polygons::show_all_lines() {
	for (int i = 0; i < polygons_num; i++)
	{
		for (int j = 0; j < this->allpolygons[i].vertex_num; j++) {
			allv[this->index].allvertices[allpolygons[i].lines[j].start].showVector();
			allv[this->index].allvertices[allpolygons[i].lines[j].end].showVector();
		}

	}
}

void polygons::randomcolor()
{
	//assign each polygon a random color
	for (int i = 0; i < polygons_num; i++)
	{
		allpolygons[i].color_r = Random();
		allpolygons[i].color_g = Random();
		allpolygons[i].color_b = Random();

	}
}

void polygons::creat_edgetable()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���
			MyVector color = { one_polygon.color_r,one_polygon.color_g,one_polygon.color_b };//��ǰ�����ɫ
			
			for (int j = 0; j < vernum; j++) {
				vertices[j] = v.allvertices[one_polygon.vertices_in_one_polygon[j]];
			}

			vector<edge> temptable = edgetables[i];
			
			for (int j = 0; j < vernum; j++)
			{
				MyVector v0, v1, v2, v3;
				float ymin, ymax, xmin, dx, zmin, dz;
				int v1x, v1y,v2x, v2y;
				edge tempedge;
				v0 = vertices[(j - 1 + vernum) % vernum];
				v3 = vertices[(j + 2 + vernum) % vernum];
				int v0y, v3y;
				v0y = (int)v0.y;
				v3y = (int)v3.y;
				//v0,v3���ڼ������
				v1 = vertices[j];
				v2 = vertices[(j + 1 + vernum) % vernum];
				v1x = (int)v1.x;
				v1y = (int)v1.y;
				v2x = (int)v2.x;
				v2y = (int)v2.y;

				//v1,v2�ǵ�ǰ�����ı�
				if (v1y==v2y) {//ˮƽ�ߺ���
					continue;
				}
				dx = ((v1.x - v2.x) / (v1y - v2y));//x over y
				dz = ((v1.z - v2.z)) / (v1y - v2y);//z over y
				if (v1y<v2y) {
					ymin = v1y;
					ymax = v2y;
					xmin = v1.x;
					zmin = v1.z;
					if (v3y > v2y) {
						//v1y<v2y<v3y ��㴦��
						ymin += 1;
						xmin += dx;
						zmin += dz;
					}
					
				}
				else {
					ymin = v2y;
					ymax = v1y;
					xmin = v2.x;
					zmin = v2.z;
					if (v1y > v0y) {
						//v2y>v1y>v0y ��㴦��
						ymin += 1;
						xmin += dx;
						zmin += dz;
					}
				}
				

				

				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;
				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;
				temptable.push_back(tempedge);//����һ��ɨ����
			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����
			edgetables[i] = temptable;
		}
	}
}


void polygons::ScanConvertion() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];
		
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			MyVector color = { one_polygon.color_r,one_polygon.color_g,one_polygon.color_b };//��ǰ�����ɫ
			int vernum = one_polygon.vertex_num;
			
			for (int j = v.ymin; j <= v.ymax+1; j++) {//��ʼɨ��
				for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if ((int)edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);					}
					else if ((int)edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {
					/*
					vector<int> start, end;
					start.push_back(AET[k].Xmin);
					start.push_back(j);
					end.push_back(AET[k+1].Xmin);
					end.push_back(j);
					*/

					MyVector start, end;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k+1].Zmin };
					//start = { (AET[k].Xmin*1.0f / 1000) - 1,(j*1.0f / 1000) - 1, 0 };
					//end = { (AET[k + 1].Xmin*1.0f / 1000) - 1,(j*1.0f / 1000) - 1, 0 };
					DrawLines.push_back(DrawLine(start, end, color));//�������Ⱦɫ����

					/*
					//����zbuffer
					int y = j;
					int x1 = (int)AET[k].Xmin;
					int x2 = (int)AET[k + 1].Xmin;
					float z1 = AET[k].Zmin; //��ǰɨ�����ϣ���ߵ�Z
					float z2 = AET[k + 1].Zmin; //��ǰɨ�����ϣ��ұߵ�Z
					if (x1 != x2) {
						for (int x = x1; x <= x2; x++)
						{
							if(x >= 2000 || x <= 0 ){
								continue;
							}

							float zp = z2 - (z2 - z1)*(x2 - x) / (x2 - x1);
							if (zp < Z_depth[x][y]) {
								Z_depth[x][y] = zp;
								Z_frame[x][y] = color;
							}
						}
					}
					else {
						float zp;
						if (z1 <= z2) { zp = z1; }
						else {zp = z2; }
						if (zp < Z_depth[x1][y]) {
							Z_depth[x1][y] = zp;
							Z_frame[x1][y] = color;
						}
					}
					*/

						
				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if ((int)AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin = AET[k].Xmin + AET[k].x_over_y;
					AET[k].Zmin = AET[k].Zmin + AET[k].z_over_y;
					//For each entry remaining in AET, replace x by x + increment
				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}