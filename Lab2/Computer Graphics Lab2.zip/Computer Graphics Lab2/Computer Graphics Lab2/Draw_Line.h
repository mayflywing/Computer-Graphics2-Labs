#ifndef __DrawLine__
#define __DrawLine__
//================================
// DrawLine.h
// ÿ������ߵ���ʼ���Լ���ɫ
//================================
class DrawLine
{
public:
	MyVector start, end;
	//vector<int> start, end;
	MyVector color;
public:
	DrawLine();
	//DrawLine(vector<int> start, vector<int>end, MyVector color);
	DrawLine(MyVector start, MyVector end, MyVector color);
	~DrawLine();

private:

};

#endif
