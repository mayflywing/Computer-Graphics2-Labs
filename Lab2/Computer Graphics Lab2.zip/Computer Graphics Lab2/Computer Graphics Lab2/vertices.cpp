#include"pch.h"
//================================
// vertices.cpp
// all vertices
//================================

vertices::vertices()
{
	this->vertices_num = 0;
}

vertices::~vertices()
{
}
void vertices::set_vertices(int index,int vertices_num)
{
	this->index = index;
	this->vertices_num = vertices_num;
	this->allvertices = new MyVector[vertices_num+1];
}



int vertices::get_vertices_num()
{
	return vertices_num;
}

void vertices::show_all_vertices()
{
	for (int i = 0; i < this->vertices_num;i++)
	{
		allvertices[i].showVector();
	}
}

void vertices::find_scan_line_scope()
{
	
	int tempmin = 9999;
	int tempmax = -9999;
	for (int i = 1; i <= vertices_num; i++)
	{
		allvertices[i] = (allvertices[i]+1.0) * 1000;//��Ϊ����������1000���������

		if (allvertices[i].y < tempmin) {
			tempmin = allvertices[i].y;
		}
		if (allvertices[i].y > tempmax) {
			tempmax = allvertices[i].y;
		}
	}
	this->ymin = (int)tempmin;
	this->ymax = (int)tempmax;
}
