#ifndef __VERTICES__
#define __VERTICES__
//================================
// vertices.h
// all vertices
//================================

class vertices
{
public:
	int index;
	int vertices_num;
	MyVector *allvertices;
	MyVector *allverticesNormal;
	MyVector *allverticesColor;
	vector<int> *adj_polygons_for_vertex;
	int ymin, ymax;//���е��ymin��ymax����scanline��ɨ�跶Χ

public:
	vertices();
	void set_vertices(int index,int vertices_num);
	~vertices();
	//void calculate_vertices_color();
	int get_vertices_num();
	void show_all_vertices();
	void find_scan_line_scope();

};

#endif //__VERTICES__