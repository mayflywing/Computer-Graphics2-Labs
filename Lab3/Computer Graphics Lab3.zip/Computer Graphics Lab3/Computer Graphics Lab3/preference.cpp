#include "pch.h"
//================================
// global variables
//================================

//��Ļ����
float h=2.0f, dnear=25.0f, dfar=200.0f;


float winWidth = 600.0, winHeight = 600.0;	//window size


//��ͷ����
MyVector C = { 0,50,-200 };
MyVector pref = { 0,0,0 };
MyVector Up = { 0,1,0 };
Camera camera;

//��Դ
MyVector LightDirection = { 60,100,-50 };
MyVector LightIntensity = { 0.5,0.5,0.5 };
MyVector LightColor = { 1,1,1};
//MyVector pointLightDirection = { 0,10,10 };
//MyVector pointLightColor = { 1,1,1 };
MyVector ambientLightIntensity = { 0.3,0.3,1 };
float fatt = 1.0f;

//shading modle
int shading_model = 3;
//1 constant shading
//2 gouraud shading 
//3 Phong shading

MyVector *objectColor = new MyVector[10];
MyVector *ka = new MyVector[10];
MyVector *kd = new MyVector[10];
MyVector *ks = new MyVector[10];
int *focus = new int[10];


//�ļ�·��
//string file_name = "D files/knight.d";

//������������
//int vertices_num;
//int polygons_num;

//���ж���
int models_num = 0;
vertices *allv = new vertices[10];
polygons *allp = new polygons[10];

vector<DrawLine> DrawLines;

//Zbuffer ��ʼ��Ϊ����ɫ
vector<float> temp1(2001, 9999.0f);
vector<MyVector> temp2(2001, MyVector{ 0,0,0 });
vector<vector<float>> Z_depth(2001,temp1);
vector<vector<MyVector>> Z_frame(2001,temp2);

//vector<vector<float>> Z_depth;
//vector<vector<MyVector>> Z_frame;

