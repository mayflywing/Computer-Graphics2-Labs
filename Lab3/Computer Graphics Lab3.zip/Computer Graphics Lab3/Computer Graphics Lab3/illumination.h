#ifndef __ILLUMINATION__
#define __ILLUMINATION__

MyVector ambientColor(MyVector ObjColor, MyVector ka, MyVector ambientLightColor);
MyVector diffuseColor(MyVector kd, MyVector ObjColor, MyVector Normal, MyVector Light);
MyVector specularColor(MyVector pointLightColor, MyVector ks, MyVector Normal, MyVector LightDirection, MyVector Camera, int focus);
MyVector illuminationModel(MyVector normal, MyVector ObjColor, MyVector ambientLightIntensity, MyVector LightIntensity, MyVector LightColor,
	MyVector LightDirection, MyVector ka, MyVector kd, MyVector ks, float fatt, MyVector Camera, int focus);


#endif