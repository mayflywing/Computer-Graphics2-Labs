#ifndef __POLYGONS__
#define __POLYGONS__
//================================
// polygons.h
// all polygons and lines
//================================
typedef struct  {
	int start, end;
}line;

typedef struct  {
	int vertex_num;
	line lines[10];
	int vertices_in_one_polygon[10];
	MyVector polygonNormal;
	bool face; //visible or not
	float color_r, color_g, color_b;//RGB
}polygon;



class polygons {
public:
	int index;
	int polygons_num;
	MyVector objectColor;
	MyVector ka, kd, ks;
	//float ka, kd, ks;
	int focus;
	polygon *allpolygons;
	vector<edge> *edgetables;
	vector<Horizon> *Horizons;
	

public:
	polygons();
	void set_polygons(int index,int polygons_num);
	void set_objectColor(MyVector objectColor);
	void set_variables(MyVector ka,MyVector kd,MyVector ks, int focus);
	~polygons();
	int get_polygons_num();
	void show_all_polygons();
	void show_all_lines();
	void randomcolor();
	void creat_edgetable1();
	void creat_edgetable2();
	void creat_edgetable3();
	void ScanConvertion1();
	void ScanConvertion2();
	void ScanConvertion3();
};


#endif //__POLYGONS__
