#ifndef __CALCULATION__
#define __CALCULATION__
//================================
// calculation.h
// some function for vector and matrix
//================================

MyVector  Xproduct(MyVector a, MyVector b);
float Distance(MyVector a, MyVector b);
float *MultiMatrix(Matrix a, Matrix b);
float Random();
int roundUp(float f);
int roundDown(float f);
MyVector VertexNormal(vector<polygon> adj_polygons);


vector<string> split(const string & s, char splitchar);
string & replace_all(string & str, const string & old_value, const string & new_value);
bool Ymincompare(const edge &e1, const edge &e2);
bool Xcompare(const edge &e1, const edge &e2);


#endif  //__CALCULATION__