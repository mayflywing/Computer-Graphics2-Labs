#ifndef __CAMERA__
#define __CAMERA__

//================================
// camera.h
// store the position of camera, the viewing direction and the up vector, 
// then calculate the camera coordinates.
//================================
class Camera {
public:
	Matrix View;
private:
	MyVector Camera_Position;
	MyVector Viewing_Direction;
	MyVector Up;
	MyVector N;
	MyVector V;
	MyVector U;

public:
	Camera();
	~Camera();
	void Coordinate(MyVector Camera_Position, MyVector Viewing_Direction, MyVector Up);
	MyVector getCamera_Position();
	void Camera_Space();
};

#endif  //__CAMERA__
