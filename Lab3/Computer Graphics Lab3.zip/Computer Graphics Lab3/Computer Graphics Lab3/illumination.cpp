#include "pch.h"


MyVector ambientColor(MyVector ObjColor, MyVector ka, MyVector ambientLightIntensity) {
	float x = ambientLightIntensity.x*ka.x*ObjColor.x;
	float y = ambientLightIntensity.y*ka.y*ObjColor.y;
	float z = ambientLightIntensity.z*ka.z*ObjColor.z;
	return MyVector(x, y, z);
}
MyVector diffuseColor(MyVector kd, MyVector ObjColor, MyVector Normal, MyVector LightDirection) {
	MyVector L = LightDirection;
	//Normal.showVector();
	//L.showVector();

	//float temp = max(0.0f, Normal.dot(L));
	float temp = Normal.dot(L);
	//cout << temp;
	float x = kd.x * ObjColor.x*temp;
	float y = kd.y * ObjColor.y*temp;
	float z = kd.z * ObjColor.z*temp;
	return MyVector(x, y, z);
}
MyVector specularColor(MyVector pointLightColor, MyVector ks, MyVector Normal, MyVector LightDirection, MyVector Camera, int focus) {
	MyVector L = LightDirection;
	MyVector V = Camera;
	//MyVector L = LightDirection - Normal;
	//MyVector V = Camera - Normal;

	MyVector H = (L + V).normalize();
	//float temp = max(0.0f,pow(Normal.dot(H), focus));
	float temp = pow(Normal.dot(H), focus);

	//MyVector r = 2 * Normal*(Normal.dot(L)) - L;
	//r = r.normalize();
	//float temp = max(0.0f, pow(V.dot(r), focus));


	float x = pointLightColor.x*temp*ks.x;
	float y = pointLightColor.y*temp*ks.y;
	float z = pointLightColor.z*temp*ks.z;

	//cout << x << y << z;
	return MyVector(x, y, z);
}

MyVector illuminationModel(MyVector normal, MyVector ObjColor, MyVector ambientLightIntensity, MyVector LightIntensity, MyVector LightColor,
	MyVector LightDirection, MyVector ka, MyVector kd, MyVector ks, float fatt, MyVector Camera, int focus)
{
	MyVector L = LightDirection.normalize();
	MyVector camera = Camera.normalize();
	MyVector N = normal.normalize();

	//MyVector L = LightDirection - normal;
	MyVector AmbientColor = ambientColor(ObjColor, ka, ambientLightIntensity);
	MyVector DiffuseColor = diffuseColor(kd, ObjColor, N, L);
	//if (DiffuseColor.x < 0 || DiffuseColor.y < 0 || DiffuseColor.z < 0) { DiffuseColor = MyVector(0, 0, 0); }
	MyVector SpecularColor = specularColor(LightColor, ks, N, L, camera, focus);
	//if(SpecularColor.x<0|| SpecularColor.y<0|| SpecularColor.z<0){ SpecularColor = MyVector(0, 0, 0);}
	float x = AmbientColor.x + fatt * LightIntensity.x*(DiffuseColor.x + SpecularColor.x);
	float y = AmbientColor.y + fatt * LightIntensity.y*(DiffuseColor.y + SpecularColor.y);
	float z = AmbientColor.z + fatt * LightIntensity.z*(DiffuseColor.z + SpecularColor.z);

	//return DiffuseColor;
    //return SpecularColor;
	return MyVector(x, y, z);
}
