#include "pch.h"
//================================
// matrix.cpp
// Four - dimensional matrix
//================================

Matrix::Matrix() {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (i == j)
				matrix[i + j * 4] = 1.0;
			else
				matrix[i + j * 4] = 0.0;
		}
	}
}

Matrix::~Matrix() {
}

void Matrix::init() {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (i == j)
				matrix[i + j * 4] = 1.0;
			else
				matrix[i + j * 4] = 0.0;
		}
	}
}

//multiply two Matrixes
void Matrix::MultiMatrix(Matrix m) {
	float temp[16];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			temp[4 * i + j] = 0.0;
			for (int k = 0; k < 4; k++) {
				temp[i * 4 + j] += matrix[4 * k + j] * m.matrix[4 * i + k];
			}
		}
	}
	for (int i = 0; i < 16; i++) {
		matrix[i] = temp[i];
	}
}

void Matrix::antiMultiMatrix(Matrix m) {
	float temp[16];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			temp[4 * i + j] = 0.0;
			for (int k = 0; k < 4; k++) {
				temp[i * 4 + j] += m.matrix[4 * k + j] * matrix[4 * i + k];
			}
		}
	}
	for (int i = 0; i < 16; i++) {
		matrix[i] = temp[i];
	}
}

//set the value of a matrix
void Matrix::SetMatrix(Matrix m) {
	for (int i = 0; i < 16; i++)
		matrix[i] = m.matrix[i];
}

//add two matrixes
void Matrix::AddMatrix(Matrix m) {
	for (int i = 0; i < 16; i++)
		matrix[i] += m.matrix[i];
}

void Matrix::showMatrix() {
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << matrix[4*j+i]<<"\t";
		}
		cout << "\n";
	}
}