#ifndef __MATRIX__
#define __MATRIX__

//================================
// matrix.h
// Four-dimensional matrix and the math functions
//================================

class Matrix {

public:
	float matrix[16];

public:
	Matrix();
	~Matrix();
	void init();
	void MultiMatrix(Matrix m);
	void antiMultiMatrix(Matrix m);
	void SetMatrix(Matrix m);
	void AddMatrix(Matrix m);
	void showMatrix();
};

#endif //__MATRIX__