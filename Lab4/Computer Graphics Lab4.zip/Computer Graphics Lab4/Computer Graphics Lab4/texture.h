#ifndef __TXETURE__
#define __TXETURE__

Mat readImg(string filename, int W, int H);
MyVector find_uv_cylinder(MyVector Normal);
MyVector find_uv_sphere(MyVector Normal);
MyVector FindColor(float u, float v, Mat img);

#endif //__TXETURE__
