#include "pch.h"
#include <opencv2/opencv.hpp>
#include "texture.h"


Mat readImg(string filename, int W, int H)
{
	//����ͼƬ
	Mat origin_img = imread(filename);
	Mat img;
	resize(origin_img, img, Size(W,H), 0, 0, INTER_CUBIC);

	//imshow("img", img);
	//waitKey(0);
	return img;
}


MyVector find_uv_cylinder(MyVector Normal)
{
	int W = TextureW;
	int H = TextureH;
	
	float R = W * 1.0 / (2 * M_PI);

	MyVector p = Normal;//(Normal+1)/2 * R;

	float z = (p.z+1)/2; //p.z from -1 to 1, z from 0 to 1
	float theta = atan(p.y / p.x); //atan from -pi/2 to pi/2
	theta = (theta + M_PI / 2)*2; //theta from 0 to 2pi
	
	float u = theta / (2*M_PI);
	float v = z;

	return MyVector(u*W,v*H,0);
}


MyVector find_uv_sphere(MyVector Normal)
{
	int W = TextureW;
	int H = TextureH;

	float X = Normal.x;
	float Y = Normal.y;
	float Z = Normal.z;

	float u = asin(X) / M_PI + 0.5;
	float v = asin(Y) / M_PI + 0.5;

	return MyVector(u*W, v*H, 0);
}

MyVector FindColor(float u, float v, Mat img)
{
	if (u > 0 && u < TextureW && v>0 && v < TextureH) {
		Scalar color = img.at<Vec3b>((int)v, (int)u);
		return MyVector(color(0) *1.0/ 255, color(1)*1.0 / 255, color(2)*1.0 / 255);
	}
	else {
		return MyVector(0, 0, 0);
	}
}
