#include "pch.h"
//================================
// projection.cpp
// the perspective matrix
//================================




Matrix perspective() {

	Matrix perspective;
	perspective.init();
	perspective.matrix[0] = dnear/h, perspective.matrix[4] = 0, perspective.matrix[8] = 0, perspective.matrix[12] = 0,
	perspective.matrix[1] = 0, perspective.matrix[5] = dnear/h, perspective.matrix[9] = 0, perspective.matrix[13] = 0,
	perspective.matrix[2] = 0, perspective.matrix[6] = 0, perspective.matrix[10] = dfar/(dfar-dnear), perspective.matrix[14] = -dnear*dfar/(dfar-dnear),
	perspective.matrix[3] = 0, perspective.matrix[7] = 0, perspective.matrix[11] = 1, perspective.matrix[15] = 0;

	return perspective;
}


MyVector model(Camera camera, MyVector v) {
	Matrix Temp;
	//Temp.SetMatrix(perspective(Theta, winWidth/winHeight,Dnear,Dfar));
	//Temp.MultiMatrix(frustum());
	Temp.SetMatrix(perspective());
	Temp.MultiMatrix(camera.View);
	
	return v * Temp;
}

void LoadData(string file_name) {
	ifstream text;
	text.open(file_name, ios::in);

	vector<string> strVec;
	while (!text.eof())  //��0 - ��lines��Ӧstrvect[0] - strvect[lines]
	{
		string inbuf;
		getline(text, inbuf, '\n');
		inbuf = replace_all(inbuf, "\t", " ");
		strVec.push_back(inbuf);
	}

	int vertices_num = stoi(split(strVec[0], ' ')[1]);
	int polygons_num = stoi(split(strVec[0], ' ')[2]);

	vertices v;
	v.set_vertices(models_num, vertices_num);
	polygons p;
	p.set_polygons(models_num, polygons_num);

	
	for (int i = 1; i <= vertices_num; i++)
	{
		float x, y, z;
		stringstream s1(split(strVec[i], ' ')[0]);
		stringstream s2(split(strVec[i], ' ')[1]);
		stringstream s3(split(strVec[i], ' ')[2]);
		s1 >> x;
		s2 >> y;
		s3 >> z;

		//MyVector temp = { x,y,z };
		v.allvertices[i] = { x,y,z };//�����Ŵ�1��ʼ
	}
	
	for (int i = vertices_num + 1; i <= vertices_num + polygons_num; i++)
	{
		polygon temp;
		temp.vertex_num = stoi(split(strVec[i], ' ')[0]);
		for (int k = 0; k < temp.vertex_num; k++)
		{
			//ÿ��������Щ��
			temp.vertices_in_one_polygon[k] = stoi(split(strVec[i], ' ')[k + 1]);
			//cout << stoi(split(strVec[i], ' ')[k + 1])<<"\t";
		}

		for (int j = 0; j < temp.vertex_num - 1; j++)
		{
			temp.lines[j].start = stoi(split(strVec[i], ' ')[j + 1]);
			temp.lines[j].end = stoi(split(strVec[i], ' ')[j + 2]);
		}
		temp.lines[temp.vertex_num - 1].end = stoi(split(strVec[i], ' ')[1]);
		temp.lines[temp.vertex_num - 1].start = stoi(split(strVec[i], ' ')[temp.vertex_num]);

		p.allpolygons[i - vertices_num - 1] = temp;//��ı�Ŵ�0��ʼ

		for (int k = 0; k < temp.vertex_num; k++)
		{
			//ÿ�����������Щ����
			v.adj_polygons_for_vertex[stoi(split(strVec[i], ' ')[k + 1])].push_back(i-vertices_num-1);
		}
	}
	
	allv[models_num] = v;
	allp[models_num] = p;
	models_num++;

	
}

void texture_mapping()
{
	img = readImg(TextureSource, TextureW, TextureH);

}

void transform() {
	camera.Coordinate(C, pref, Up);
	camera.Camera_Space();

	for (int i = 0; i < models_num; i++) {
		vertices v = allv[i];
		for (int j = 1; j <= v.get_vertices_num(); j++)
		{
			v.allvertices[j] = model(camera, v.allvertices[j]);
		}
	}
}

void back_face_culling() {
	//ȥ��������camera����
	for (int i = 0; i < models_num; i++)
	{
		vertices v = allv[i];
		polygons p = allp[i];
		for (int j = 0; j < p.polygons_num; j++) {
			MyVector v1, v2, v3, line1, line2, normal;
			v1 = v.allvertices[p.allpolygons[j].lines[0].start];
			v2 = v.allvertices[p.allpolygons[j].lines[0].end];
			v3 = v.allvertices[p.allpolygons[j].lines[1].end];
			line1 = v2 - v1;
			line2 = v3 - v2;
			normal = Xproduct(line1, line2);

			if (normal.z > 0) {
				//z>0 back face
				p.allpolygons[j].face = false;
			}

			/*cout << "polygon" << j << ": ";
			normal.showVector();*/
		}
	}
}

void calculate_polygon_normal() {
	for (int i = 0; i < models_num; i++)
	{
		vertices v = allv[i];
		polygons p = allp[i];
		for (int j = 0; j < p.polygons_num; j++) {
			MyVector v1, v2, v3, line1, line2, normal;
			v1 = v.allvertices[p.allpolygons[j].lines[0].start];
			v2 = v.allvertices[p.allpolygons[j].lines[0].end];
			v3 = v.allvertices[p.allpolygons[j].lines[1].end];

			//cout << "polygon" << j << ": ";//<< p.allpolygons[j].lines[0].start << "\t"<<p.allpolygons[j].lines[0].end <<"\t"<< p.allpolygons[j].lines[1].end<<endl;
			
			line1 = v2 - v1;
			line2 = v3 - v2;
			normal = Xproduct(line1, line2);
			p.allpolygons[j].polygonNormal = normal.normalize();
			//p.allpolygons[j].polygonNormal.showVector();
		}
		for (int j = 0; j < p.polygons_num; j++) {
			//cout << "polygon :" << j;
			//p.allpolygons[j].polygonNormal.showVector();
		}
	}
}

void calculate_vertex_normal()
{
	for (int i = 0; i < models_num; i++)
	{
		vertices v = allv[i];
		polygons p = allp[i];
		for (int j = 1; j <= v.vertices_num;j++) {
			//��ÿ���㣬����vertex_normal;
			MyVector temp;
			vector<int> adj_polygons= v.adj_polygons_for_vertex[j];
			//cout << "for vertex " << j << ": " << endl;
			for (int k = 0; k < adj_polygons.size(); k++)
			{
				//cout << "polygon: "<<adj_polygons[k] << "\t";
				//p.allpolygons[adj_polygons[k]].polygonNormal.showVector();
				temp += p.allpolygons[adj_polygons[k]].polygonNormal;//�������ڵ�polygon_normal
			}
			
			//temp = temp.normalize();
			v.allverticesNormal[j] = temp.normalize();//(N1+N2+N3)/||(N1+N2+N3)||
		}
	}
}

void scanline() {
	for (int i = 0; i < models_num; i++)
	{
		//���ģ�ͣ��ֱ�ɨ��ÿ����
		allv[i].find_scan_line_scope(); //in vertices.cpp
		allp[i].randomcolor();//��ȡ���ɫ  //in polygons.cpp
		allp[i].set_objectColor(objectColor[i]);
		allp[i].set_variables(ka[i],kd[i],ks[i],focus[i]);

		if (shading_model == 0) {
			//allp[i].randomcolor();
			//allp[i].allpolygons[0].color_r = 1.0; allp[i].allpolygons[0].color_g = 0.0; allp[i].allpolygons[0].color_b = 0.0; //����
			//allp[i].allpolygons[1].color_r = 0.0; allp[i].allpolygons[1].color_g = 1.0; allp[i].allpolygons[1].color_b = 0.0;
			//allp[i].allpolygons[2].color_r = 0.0; allp[i].allpolygons[2].color_g = 0.0; allp[i].allpolygons[2].color_b = 1.0;
			//allp[i].allpolygons[3].color_r = 1.0; allp[i].allpolygons[3].color_g = 1.0; allp[i].allpolygons[3].color_b = 1.0;  //����
			//allp[i].allpolygons[4].color_r = 1.0; allp[i].allpolygons[4].color_g = 0.8; allp[i].allpolygons[4].color_b = 0.0;
			//allp[i].allpolygons[5].color_r = 0.8; allp[i].allpolygons[5].color_g = 1.0; allp[i].allpolygons[5].color_b = 0.0;


			allp[i].creat_edgetable1(); //����edgetable //in polygons.cpp
			allp[i].ScanConvertion1(); //���ÿ���� //in polygons.cpp
		
		}
		if (shading_model == 1) {
			allp[i].creat_edgetable1(); //����edgetable //in polygons.cpp
			allp[i].ScanConvertion1(); //���ÿ���� //in polygons.cpp
		}
		if (shading_model == 2) {
			calculate_vertex_normal();
			allp[i].creat_edgetable2(); //����edgetable //in polygons.cpp
			allp[i].ScanConvertion2(); //���ÿ���� //in polygons.cpp
		}
		if (shading_model == 3) {
			calculate_vertex_normal();
			allp[i].creat_edgetable3(); //����edgetable //in polygons.cpp
			allp[i].ScanConvertion3(); //���ÿ���� //in polygons.cpp
		}
		if (shading_model == 4) {
			allp[i].creat_edgetable4(); //����edgetable //in polygons.cpp
			allp[i].ScanConvertion4(); //���ÿ���� //in polygons.cpp

		}
	}
}

