#include "pch.h"
//================================
// polygons.cpp
// all polygons and lines
//================================
polygons::polygons()
{
	this->polygons_num = 0;
	this->objectColor = { 0.5,0.5,0.5 };
}

void polygons::set_polygons(int index,int polygons_num)
{
	this->index = index;
	this->polygons_num = polygons_num;
	this->allpolygons = new polygon[polygons_num];
	this->edgetables = new vector<edge>[polygons_num];
	this->Horizons = new vector<Horizon>[polygons_num];
}

void polygons::set_objectColor(MyVector objectColor)
{
	this->objectColor = objectColor;
}

void polygons::set_variables(MyVector ka, MyVector kd, MyVector ks, int focus)
{
	this->ka = ka;
	this->kd = kd;
	this->ks = ks;
	this->focus = focus;
}


polygons::~polygons()
{
}

int polygons::get_polygons_num()
{
	return polygons_num;
}

void polygons::show_all_polygons()
{
	for (int i = 0; i < polygons_num; i++)
	{
		cout << allpolygons[i].vertex_num<<endl;
		for(int j = 0;j< allpolygons[i].vertex_num;j++)
		cout << allpolygons[i].lines[j].start<<"\t"<< allpolygons[i].lines[j].end<<endl;
	}
}

void polygons::show_all_lines() {
	for (int i = 0; i < polygons_num; i++)
	{
		for (int j = 0; j < this->allpolygons[i].vertex_num; j++) {
			allv[this->index].allvertices[allpolygons[i].lines[j].start].showVector();
			allv[this->index].allvertices[allpolygons[i].lines[j].end].showVector();
		}

	}
}

void polygons::randomcolor()
{
	//assign each polygon a random color
	for (int i = 0; i < polygons_num; i++)
	{
		allpolygons[i].color_r = Random();
		allpolygons[i].color_g = Random();
		allpolygons[i].color_b = Random();

	}
}

void polygons::creat_edgetable1()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���
			
			for (int j = 0; j < vernum; j++) {
				vertices[j] = v.allvertices[one_polygon.vertices_in_one_polygon[j]];
			}

			vector<edge> temptable = edgetables[i];
			
			for (int j = 0; j < vernum; j++)
			{
				MyVector v0,v3,v1, v2;
				float ymin, ymax, xmin, dx, zmin, dz;
				edge tempedge;
				v0 = vertices[(j - 1 + vernum) % vernum];
				v3 = vertices[(j + 2 + vernum) % vernum];

				v1 = vertices[j];
				v2 = vertices[(j + 1 + vernum) % vernum];



				//v1,v2�ǵ�ǰ�����ı�
				dx = ((v1.x - v2.x) / (v1.y - v2.y));//x over y
				dz = ((v1.z - v2.z)) / (v1.y - v2.y);//z over y


				if ((int)v1.y==(int)v2.y) {//ˮƽ�ߺ���
					Horizons[i].push_back(Horizon(v1, v2));
					//Horizons.push_back(Horizon(v1, v2));
					continue;
				}

				if (v1.y<v2.y) {
						ymin = roundDown(v1.y);
						ymax = roundDown(v2.y)-1;
						xmin = v1.x;
						zmin = v1.z;
					
				}
				else if (v1.y>v2.y){
					ymin = roundDown(v2.y);
					ymax = roundDown(v1.y)-1;
					xmin = v2.x;
					zmin = v2.z;

				}
				
			
				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;
				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;
				temptable.push_back(tempedge);//����һ��ɨ����

			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����
			edgetables[i] = temptable;
		}
	}
}
void polygons::creat_edgetable2()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];
	for (int i = 1; i <= v.vertices_num; i++)
	{
		//calculate the color of each vertex
		v.allverticesColor[i] = illuminationModel(v.allverticesNormal[i], objectColor,
			ambientLightIntensity, LightIntensity,LightColor, LightDirection,
			ka, kd, ks, fatt, camera.getCamera_Position(), focus);
	}
	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���
			MyVector *verticesColor = new MyVector[vernum];

			for (int j = 0; j < vernum; j++) {
				int vindex = one_polygon.vertices_in_one_polygon[j];
				vertices[j] = v.allvertices[vindex];
				verticesColor[j] = v.allverticesColor[vindex];
				//verticesColor[j].showVector();
			}

			vector<edge> temptable = edgetables[i];

			for (int j = 0; j < vernum; j++)
			{
				MyVector  v1, v2,v1Color,v2Color;
				float ymin, ymax, xmin, dx, zmin, dz;
				MyVector minColor;
				float dr, dg, db; //rgb
				edge tempedge;

				v1 = vertices[j];
				v1Color = verticesColor[j];
				v2 = vertices[(j + 1 + vernum) % vernum];
				v2Color = verticesColor[(j + 1 + vernum) % vernum];


				//v1,v2�ǵ�ǰ�����ı�
				dx = ((v1.x - v2.x) / (v1.y - v2.y));//x over y
				dz = ((v1.z - v2.z)) / (v1.y - v2.y);//z over y
				dr = (v1Color.x - v2Color.x) / (v1.y - v2.y); //red
				dg = (v1Color.y - v2Color.y) / (v1.y - v2.y); //green
				db = (v1Color.z - v2Color.z) / (v1.y - v2.y); //blue




				if ((int)v1.y == (int)v2.y) {//ˮƽ�ߺ���
					Horizons[i].push_back(Horizon(v1, v2, v1Color, v2Color));
					continue;
				}

				if (v1.y < v2.y) {
					//V1����
					ymin = roundDown(v1.y);
					ymax = roundDown(v2.y)-1;
					xmin = v1.x;
					zmin = v1.z;
					minColor = v1Color;
					
				}
				else {
					//V2����
					ymin = roundDown(v2.y);
					ymax = roundDown(v1.y)-1;
					xmin = v2.x;
					zmin = v2.z;
					minColor = v2Color;
					
				}
				
				

				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;

				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;

				tempedge.rmin = minColor.x;
				tempedge.gmin = minColor.y;
				tempedge.bmin = minColor.z;
				tempedge.dr = dr;
				tempedge.dg = dg;
				tempedge.db = db;

				temptable.push_back(tempedge);//����һ��ɨ����
			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����

			edgetables[i] = temptable;
		}
	}
}
void polygons::creat_edgetable3()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];
	
	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			

			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���
			MyVector *verticesNormal = new MyVector[vernum];

			for (int j = 0; j < vernum; j++) {
				vertices[j] = v.allvertices[one_polygon.vertices_in_one_polygon[j]];
				verticesNormal[j] = v.allverticesNormal[one_polygon.vertices_in_one_polygon[j]];
			}


			vector<edge> temptable = edgetables[i];

			for (int j = 0; j < vernum; j++)
			{
				MyVector v1, v2, v1Normal, v2Normal;
				float ymin, ymax, xmin, dx, zmin, dz;
				MyVector minNormal;
				float dnx,dny,dnz; //normal
				edge tempedge;
				

				v1 = vertices[j];
				v1Normal = verticesNormal[j];
				v2 = vertices[(j + 1 + vernum) % vernum];
				v2Normal = verticesNormal[(j + 1 + vernum) % vernum];


				//v1,v2�ǵ�ǰ�����ı�
				if ((int)v1.y == (int)v2.y) {//ˮƽ�ߺ���
					Horizons[i].push_back(Horizon(v1, v2, v1Normal, v2Normal));
					continue;
				}
				dx = (v1.x - v2.x) / (v1.y - v2.y);//x over y
				dz = (v1.z - v2.z) / (v1.y - v2.y);//z over y

				dnx = (v1Normal.x - v2Normal.x) / (v1.y - v2.y); //normal x
				dny = (v1Normal.y - v2Normal.y) / (v1.y - v2.y); //normal y
				dnz = (v1Normal.z - v2Normal.z) / (v1.y - v2.y); //normal z



				if (v1.y < v2.y) {
					ymin = (int)v1.y;
					ymax = (int)v2.y-1;
					xmin = v1.x;
					zmin = v1.z;
					minNormal = v1Normal;
					

				}
				else {
					ymin = (int)v2.y;
					ymax = (int)v1.y-1;
					xmin = v2.x;
					zmin = v2.z;
					minNormal = v2Normal;
				}




				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;

				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;

				tempedge.nxmin = minNormal.x;
				tempedge.nymin = minNormal.y;
				tempedge.nzmin = minNormal.z;
				tempedge.dnx = dnx;
				tempedge.dny = dny;
				tempedge.dnz = dnz;


				temptable.push_back(tempedge);//����һ��ɨ����
			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����
			edgetables[i] = temptable;
		}
	}
}
void polygons::creat_edgetable4()
{
	//creat the edge table for each polygon
	vertices v = allv[this->index];

	for (int i = 0; i < polygons_num; i++)
	{
		//����ÿ�����Լ���edgetable
		polygon one_polygon = this->allpolygons[i];
		if (one_polygon.face) {//ֻ������ʾ����Щ��



			int vernum = one_polygon.vertex_num;//����Ķ�������
			MyVector *vertices = new MyVector[vernum];//����Ķ���
			MyVector *verticesNormal = new MyVector[vernum];
			MyVector *verticesTexture = new MyVector[vernum];

			for (int j = 0; j < vernum; j++) {
				vertices[j] = v.allvertices[one_polygon.vertices_in_one_polygon[j]];
				verticesNormal[j] = v.allverticesNormal[one_polygon.vertices_in_one_polygon[j]];
				verticesTexture[j] = v.allverticesTexture[one_polygon.vertices_in_one_polygon[j]];

			}


			vector<edge> temptable = edgetables[i];

			for (int j = 0; j < vernum; j++)
			{
				MyVector v1, v2, v1Normal, v2Normal;
				float ymin, ymax, xmin, dx, zmin, dz;
				MyVector minNormal,minTexture;
				float dnx, dny, dnz; //normal

				edge tempedge;


				v1 = vertices[j];
				v1Normal = verticesNormal[j];
				v2 = vertices[(j + 1 + vernum) % vernum];
				v2Normal = verticesNormal[(j + 1 + vernum) % vernum];


				//v1,v2�ǵ�ǰ�����ı�
				if ((int)v1.y == (int)v2.y) {//ˮƽ�ߺ���
					continue;
				}
				dx = (v1.x - v2.x) / (v1.y - v2.y);//x over y
				dz = (v1.z - v2.z) / (v1.y - v2.y);//z over y

				dnx = (v1Normal.x - v2Normal.x) / (v1.y - v2.y); //normal x
				dny = (v1Normal.y - v2Normal.y) / (v1.y - v2.y); //normal y
				dnz = (v1Normal.z - v2Normal.z) / (v1.y - v2.y); //normal z

				if (v1.y < v2.y) {
					ymin = (int)v1.y;
					ymax = (int)v2.y - 1;
					xmin = v1.x;
					zmin = v1.z;
					minNormal = v1Normal;


				}
				else {
					ymin = (int)v2.y;
					ymax = (int)v1.y - 1;
					xmin = v2.x;
					zmin = v2.z;
					minNormal = v2Normal;
				}




				tempedge.Ymin = ymin;
				tempedge.Ymax = ymax;
				tempedge.Xmin = xmin;
				tempedge.x_over_y = dx;

				tempedge.Zmin = zmin;
				tempedge.z_over_y = dz;

				tempedge.nxmin = minNormal.x;
				tempedge.nymin = minNormal.y;
				tempedge.nzmin = minNormal.z;
				tempedge.dnx = dnx;
				tempedge.dny = dny;
				tempedge.dnz = dnz;



				temptable.push_back(tempedge);//����һ��ɨ����
			}
			sort(temptable.begin(), temptable.end(), Ymincompare);//��edgetable����ymin����
			edgetables[i] = temptable;
		}
	}
}

void polygons::ScanConvertion1() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];
		
		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			MyVector color = { one_polygon.color_r,one_polygon.color_g,one_polygon.color_b };//��ǰ�����ɫ
			int vernum = one_polygon.vertex_num;

			
				//constant shading, each polygon one color
				MyVector constantColor;
				
				constantColor = illuminationModel(one_polygon.polygonNormal, objectColor,
					ambientLightIntensity,LightIntensity, LightColor, LightDirection, 
					ka, kd, ks, fatt, camera.getCamera_Position(), focus);
				
				
				
				color = constantColor;


				for (int h = 0; h < Horizons[i].size(); h++) {
					//����ˮƽ��
					Horizons[i][h].Constant_DrawHorizon(color);
				}
			
				for (int j = v.ymin-1; j <= v.ymax+1; j++) {//��ʼɨ��
					for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if (edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);
					}
					else if (edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {

					MyVector start, end;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k+1].Zmin };
					
					DrawLine temp = DrawLine(start, end, color);
					DrawLines.push_back(temp);//�������Ⱦɫ����


					int y = j;
					if (y > 2000 || y < 0) {
						
					}
					else {
						MyVector left, right;

						left = start;
						right = end;


						int x1 = (int)left.x;
						int x2 = (int)right.x;
						float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
						float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z
						float zoverx = (z2 - z1) / (right.x-left.x);
						float zp = z1;

						for (int x = x1; x <= x2; x++)
							{
								if (x > 2000 || x < 0) {
									
								}
								else if (zp <= Z_depth[x][y]) {
									Z_depth[x][y] = zp;
									Z_frame[x][y] = color;
								}
								zp += zoverx;
							}
						}
					
	
				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if (AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin = AET[k].Xmin + AET[k].x_over_y;
					AET[k].Zmin = AET[k].Zmin + AET[k].z_over_y;
					//For each entry remaining in AET, replace x by x + increment
				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}
void polygons::ScanConvertion2() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];

		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			//MyVector color;// = { one_polygon.color_r,one_polygon.color_g,one_polygon.color_b };
			int vernum = one_polygon.vertex_num;

			
			for (int h = 0; h < Horizons[i].size(); h++) {
				//cout << Horizons[i].size();
				Horizons[i][h].Gouraud_DrawHorizon();
			}

			
			for (int j = v.ymin-1; j <= v.ymax + 1; j++) {//��ʼɨ��
				// j == Y����
				for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if (edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);
					}
					else if (edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {

					MyVector start, end;
					MyVector startColor, endColor;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k + 1].Zmin };

					startColor = { AET[k].rmin,AET[k].gmin,AET[k].bmin };
					endColor = { AET[k+1].rmin,AET[k+1].gmin,AET[k+1].bmin };
					
					
					int y = (int)start.y;
					if (y > 2000 || y < 0) {
						//������Χ
					}
					else {
						MyVector left, right;
						MyVector leftColor, rightColor;

						left = start;
						right = end;
						leftColor = startColor;
						rightColor = endColor;


						int x1 = (int)left.x;
						int x2 = (int)right.x;
						float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
						float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z

						float zoverx = (z2 - z1) / (right.x-left.x);

						float r1 = leftColor.x;
						float r2 = rightColor.x;
						float roverx = (r2 - r1) / (right.x-left.x);

						float g1 = leftColor.y;
						float g2 = rightColor.y;
						float goverx = (g2 - g1) / (right.x-left.x);

						float b1 = leftColor.z;
						float b2 = rightColor.z;
						float boverx = (b2 - b1) / (right.x-left.x);

						float zp = z1;
						float rp = r1;
						float gp = g1;
						float bp = b1;
						

						for (int x = x1; x <= x2; x++)
							{
								if (x > 2000 || x < 0) {
									
								}
								else {

									if (zp < Z_depth[x][y]) {
										Z_depth[x][y] = zp;
										Z_frame[x][y] = { rp, gp, bp };
									}
								}
							zp += zoverx;
							rp += roverx;
							gp += goverx;
							bp += boverx;
						}
						
							
						
					}



				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if (AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin += AET[k].x_over_y;//For each entry remaining in AET, replace x by x + increment
					AET[k].Zmin += AET[k].z_over_y;//For each entry remaining in AET, replace z by z + increment
					AET[k].rmin += AET[k].dr;
					AET[k].gmin += AET[k].dg;
					AET[k].bmin += AET[k].db;
					
				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}
void polygons::ScanConvertion3() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];

		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			int vernum = one_polygon.vertex_num;

			for (int h = 0; h < Horizons[i].size(); h++) {
				//cout << Horizons[i].size();
				
				Horizons[i][h].Phong_DrawHorizon(objectColor,ka,kd,ks,focus);
			}

			for (int j = v.ymin; j <= v.ymax + 1; j++) {//��ʼɨ��
				for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if (edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);
					}
					else if (edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {

					MyVector start, end;
					MyVector startNormal, endNormal;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k + 1].Zmin };

					startNormal = { AET[k].nxmin,AET[k].nymin,AET[k].nzmin };
					endNormal = { AET[k + 1].nxmin,AET[k + 1].nymin,AET[k + 1].nzmin };



					int y = (int)start.y;
					if (y > 2000 || y < 0) {
						
					}
					else {
						MyVector left, right;
						MyVector leftNormal, rightNormal;

						left = start;
						right = end;
						leftNormal = startNormal;
						rightNormal = endNormal;


						int x1 = (int)left.x;
						int x2 = (int)right.x;
						float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
						float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z
						float nx1 = leftNormal.x;
						float nx2 = rightNormal.x;
						float ny1 = leftNormal.y;
						float ny2 = rightNormal.y;
						float nz1 = leftNormal.z;
						float nz2 = rightNormal.z;



						float zoverx = (z2 - z1) / (right.x-left.x);
						float nxoverx = (nx2 - nx1) / (right.x - left.x);
						float nyoverx = (ny2 - ny1) / (right.x - left.x); 
						float nzoverx = (nz2 - nz1) / (right.x - left.x);



						float zp = z1;
						float nxp = nx1;
						float nyp = ny1;
						float nzp = nz1;

						for (int x = x1; x <= x2; x++)
							{
								if (x > 2000 || x < 0) {

								}
								else {
									if (zp < Z_depth[x][y]) {
										Z_depth[x][y] = zp;

										MyVector pixelColor = illuminationModel(MyVector(nxp, nyp, nzp), objectColor,
											ambientLightIntensity, LightIntensity, LightColor, LightDirection,
											ka, kd, ks, fatt, camera.getCamera_Position(), focus);

										Z_frame[x][y] = pixelColor;
									}
									zp += zoverx;
									nxp += nxoverx;
									nyp += nyoverx;
									nzp += nzoverx;
								}
						}
						
						
					}



				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if ((int)AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin += AET[k].x_over_y;//For each entry remaining in AET, replace x by x + increment
					AET[k].Zmin += AET[k].z_over_y;//For each entry remaining in AET, replace z by z + increment

					AET[k].nxmin += AET[k].dnx;
					AET[k].nymin += AET[k].dny;
					AET[k].nzmin += AET[k].dnz;

				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}
void polygons::ScanConvertion4() {
	//use AET to fulfill the polygons
	vertices v = allv[this->index];
	for (int i = 0; i < polygons_num; i++)
	{
		polygon one_polygon = this->allpolygons[i];

		if (one_polygon.face) {//ֻ������ʾ����Щ��

			vector<edge> AET;//active edge table
			vector<edge> edgetable = this->edgetables[i];//edge table
			int vernum = one_polygon.vertex_num;

			for (int j = v.ymin; j <= v.ymax + 1; j++) {//��ʼɨ��
				for (int k = 0; k < edgetable.size(); k++)
				{
					//add edges whose yMin equal to AET
					if (edgetable[k].Ymin == j) {
						AET.push_back(edgetable[k]);
					}
					else if (edgetable[k].Ymin > j) {
						break;//����edgetable�Ѿ�����Ymin������������Ymin��j�Ϳ����˳�ѭ��
					}

				}
				sort(AET.begin(), AET.end(), Xcompare);//��AET������X����

				for (int k = 0; k < AET.size() / 2; k = k + 2) {

					MyVector start, end;
					MyVector startNormal, endNormal;
					start = { AET[k].Xmin,j*1.0f,AET[k].Zmin };
					end = { AET[k + 1].Xmin,j*1.0f,AET[k + 1].Zmin };

					startNormal = { AET[k].nxmin,AET[k].nymin,AET[k].nzmin };
					endNormal = { AET[k + 1].nxmin,AET[k + 1].nymin,AET[k + 1].nzmin };


					int y = (int)start.y;
					if (y > 2000 || y < 0) {

					}
					else {
						MyVector left, right;
						MyVector leftNormal, rightNormal;

						left = start;
						right = end;
						leftNormal = startNormal;
						rightNormal = endNormal;


						int x1 = (int)left.x;
						int x2 = (int)right.x;
						float z1 = left.z; //��ǰɨ�����ϣ���ߵ�Z
						float z2 = right.z; //��ǰɨ�����ϣ��ұߵ�Z
						float nx1 = leftNormal.x;
						float nx2 = rightNormal.x;
						float ny1 = leftNormal.y;
						float ny2 = rightNormal.y;
						float nz1 = leftNormal.z;
						float nz2 = rightNormal.z;


						float zoverx = (z2 - z1) / (right.x - left.x);
						float nxoverx = (nx2 - nx1) / (right.x - left.x);
						float nyoverx = (ny2 - ny1) / (right.x - left.x);
						float nzoverx = (nz2 - nz1) / (right.x - left.x);



						float zp = z1;
						float nxp = nx1;
						float nyp = ny1;
						float nzp = nz1;

						for (int x = x1; x <= x2; x++)
						{
							if (x > 2000 || x < 0) {

							}
							else {
								if (zp < Z_depth[x][y]) {
									Z_depth[x][y] = zp;
									MyVector uv;
									if (mapping_model == 1) {
										uv = find_uv_cylinder(MyVector(nxp, nyp, nzp));
									}
									if (mapping_model == 2) {
										uv = find_uv_sphere(MyVector(nxp, nyp, nzp));
									}
									MyVector pixelColor = illuminationModel(MyVector(nxp, nyp, nzp), FindColor(uv.x,uv.y,img),
										ambientLightIntensity, LightIntensity, LightColor, LightDirection,
										ka, kd, ks, fatt, camera.getCamera_Position(), focus);

									Z_frame[x][y] = pixelColor;
								}
								zp += zoverx;
								nxp += nxoverx;
								nyp += nyoverx;
								nzp += nzoverx;
							}
						}


					}



				}
				for (int k = 0; k < AET.size(); k++) {
					//Remove from AET entries for which y = ymax (leave edges) 
					if ((int)AET[k].Ymax == j) {
						AET.erase(AET.begin() + k);
						k--;
					}
				}
				for (int k = 0; k < AET.size(); k++) {
					AET[k].Xmin += AET[k].x_over_y;//For each entry remaining in AET, replace x by x + increment
					AET[k].Zmin += AET[k].z_over_y;//For each entry remaining in AET, replace z by z + increment

					AET[k].nxmin += AET[k].dnx;
					AET[k].nymin += AET[k].dny;
					AET[k].nzmin += AET[k].dnz;

					AET[k].umin += AET[k].du;
					AET[k].vmin += AET[k].dv;

				}

				sort(AET.begin(), AET.end(), Xcompare);//�ٴν�AET������X����
			}

		}
	}
}