#ifndef __Horizon__
#define __Horizon__
class Horizon
{
public:
	MyVector start, end;
	MyVector startV, endV;
public:
	Horizon();
	Horizon(MyVector start, MyVector end);
	Horizon(MyVector start, MyVector end, MyVector startV, MyVector endV);
	~Horizon();
	void Constant_DrawHorizon(MyVector color);
	void Gouraud_DrawHorizon();
	void Phong_DrawHorizon(MyVector objectColor, MyVector ka, MyVector kd, MyVector ks, int focus);

private:

};
#endif
