#include "pch.h"

edge::edge()
{
}

edge::~edge()
{
}

edge & edge::operator=(const edge & e)
{
	Ymin = e.Ymin;
	Ymax = e.Ymax;
	Xmin = e.Xmin;
	Zmin = e.Zmin;
	x_over_y = e.x_over_y;
	z_over_y = e.z_over_y;

	rmin = e.rmin;
	gmin = e.gmin;
	bmin = e.bmin;


	dr = e.dr;
	dg = e.dg; 
	db = e.db;


	nxmin = e.nxmin;
	nymin = e.nymin;
	nzmin = e.nzmin;

	dnx = e.dnx;
	dny = e.dny;
	dnz = e.dnz;

	umin = e.umin;
	vmin = e.vmin;
	du = e.du;
	dv = e.dv;
	
	return *this;
}

